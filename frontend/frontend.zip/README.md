
  # Maid Cafe Service App

  This is a code bundle for Maid Cafe Service App. The original project is available at https://www.figma.com/design/4bvZRy7w4zg3caqM5gR3ai/Maid-Cafe-Service-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  